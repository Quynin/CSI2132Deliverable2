package com.CSI2132Deliverable2;

public enum BookingStatus {

    BOOKING,
    RENTING,
    ARCHIVED

}
